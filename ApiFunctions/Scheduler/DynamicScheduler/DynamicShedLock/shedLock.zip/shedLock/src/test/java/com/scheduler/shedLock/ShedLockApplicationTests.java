package com.scheduler.shedLock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShedLockApplicationTests {

	@Test
	void contextLoads() {
	}

}
