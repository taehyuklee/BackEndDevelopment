package com.taehyuk._auth.auth_core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
